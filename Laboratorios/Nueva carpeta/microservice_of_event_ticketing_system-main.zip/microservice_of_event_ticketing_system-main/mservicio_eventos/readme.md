# Eventos Service

Este es el servicio de gestión de eventos para el sistema de venta de entradas, implementado con Go, Gin y MongoDB.

## Requisitos

- Go 1.16+
- MongoDB 4.4+
- Docker (opcional)

## Instalación

### Clonación del repositorio

```bash
git clone https://github.com/tuusuario/eventos-service.git
cd eventos-service
```

### Configuración

1. Copia el archivo de ejemplo `.env.example` a `.env` y configura las variables de entorno según tu entorno:

```bash
cp .env.example .env
```

2. Configura estas variables en el archivo `.env`:
```
SERVER_PORT=8082
SERVER_HOST=localhost
MONGODB_URI=mongodb://localhost:27017
MONGODB_DATABASE=eventos_service
JWT_SECRET=tu_clave_secreta_jwt_muy_segura
```

## Ejecución

### Modo desarrollo

```bash
go run cmd/api/main.go
```

### Construcción y ejecución

```bash
go build -o eventos-service ./cmd/api
./eventos-service
```

### Docker

```bash
# Construir la imagen
docker build -t eventos-service .

# Ejecutar el contenedor
docker run -p 8082:8082 --env-file .env eventos-service
```

## API Endpoints

### Públicos

- `GET /api/v1/events` - Obtener todos los eventos activos
- `GET /api/v1/events/:id` - Obtener un evento por ID

### Protegidos (requieren autenticación y rol de administrador)

- `POST /api/v1/events` - Crear un nuevo evento
- `PUT /api/v1/events/:id` - Actualizar un evento existente
- `DELETE /api/v1/events/:id` - Eliminar un evento (borrado lógico)

### Documentación Swagger

La documentación de la API está disponible en:
```
http://localhost:8082/swagger/index.html
```

## Autenticación

Este servicio utiliza JWT para autenticar las solicitudes. El token debe enviarse en el encabezado de autorización:

```
Authorization: Bearer {token}
```

El token JWT debe ser obtenido del servicio de autenticación.