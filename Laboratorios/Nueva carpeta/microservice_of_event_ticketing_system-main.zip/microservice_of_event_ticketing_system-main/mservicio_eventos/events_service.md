# PROJECT EVENTS SERVICE

## project preparation
```
mkdir -p eventos-service
cd eventos-service
go mod init github.com/tuusuario/eventos-service
```

## install dependencies
```
go get github.com/gin-gonic/gin
go get go.mongodb.org/mongo-driver/mongo
go get github.com/dgrijalva/jwt-go
go get github.com/joho/godotenv
go get github.com/swaggo/gin-swagger
go get github.com/swaggo/swag/cmd/swag
go get github.com/swaggo/files
```

## install swag tools
```
go install github.com/swaggo/swag/cmd/swag@latest
```

## generation swager documentation after implement the code
```
swag init -g cmd/api/main.go -o docs

run the service:
go run cmd/api/main.go

construction for production:
go build -o eventos-service ./cmd/api
```

# consumir endpoints desde swagger desde la siguiente url:
```
http://localhost:8082/swagger/index.html
```
