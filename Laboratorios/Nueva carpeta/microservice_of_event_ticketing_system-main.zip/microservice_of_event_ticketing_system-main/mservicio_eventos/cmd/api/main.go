// cmd/api/main.go
package main

import (
	"context"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/joho/godotenv"
	swaggerFiles "github.com/swaggo/files"
	ginSwagger "github.com/swaggo/gin-swagger"
	"github.com/tuusuario/eventos-service/docs"
	"github.com/tuusuario/eventos-service/internal/config"
	"github.com/tuusuario/eventos-service/internal/handlers"
	"github.com/tuusuario/eventos-service/internal/middleware"
	"github.com/tuusuario/eventos-service/internal/repository"
	"github.com/tuusuario/eventos-service/internal/service"
)

// @title           Eventos Service API
// @version         1.0
// @description     API para la gestión de eventos del sistema de venta de entradas
// @termsOfService  http://swagger.io/terms/

// @contact.name   API Support
// @contact.url    http://www.example.com/support
// @contact.email  support@example.com

// @license.name  Apache 2.0
// @license.url   http://www.apache.org/licenses/LICENSE-2.0.html

// @host      localhost:8082
// @BasePath  /api/v1

// @securityDefinitions.apikey  BearerAuth
// @in header
// @name Authorization
// @description Tipo: Bearer Token
func main() {
	// Cargar variables de entorno
	if err := godotenv.Load(); err != nil {
		log.Println("No .env file found, using environment variables")
	}

	// Cargar configuración
	cfg := config.LoadConfig()

	// Conectar a MongoDB
	mongoClient, err := config.ConnectMongoDB(cfg)
	if err != nil {
		log.Fatalf("Error connecting to MongoDB: %v", err)
	}
	defer mongoClient.Disconnect(context.Background())

	// Inicializar el repositorio, servicio y handler
	eventRepo := repository.NewEventRepository(mongoClient, cfg.MongoDB.Database)
	eventService := service.NewEventService(eventRepo)
	eventHandler := handlers.NewEventHandler(eventService)

	// Configurar Gin
	router := gin.Default()
	router.Use(gin.Recovery())
	router.Use(middleware.CORS())

	// Configurar Swagger
	docs.SwaggerInfo.BasePath = "/api/v1"
	docs.SwaggerInfo.Host = cfg.Server.Host + ":" + cfg.Server.Port
	router.GET("/swagger/*any", ginSwagger.WrapHandler(swaggerFiles.Handler))

	// Rutas de la API
	v1 := router.Group("/api/v1")
	{
		events := v1.Group("/events")
		{
			// Rutas públicas
			events.GET("", eventHandler.GetAllEvents)
			events.GET("/:id", eventHandler.GetEventByID)

			// Rutas protegidas (requieren autenticación)
			authEvents := events.Group("")
			authEvents.Use(middleware.JWTAuth())
			{
				authEvents.POST("", middleware.RequireAdmin(), eventHandler.CreateEvent)
				authEvents.PUT("/:id", middleware.RequireAdmin(), eventHandler.UpdateEvent)
				authEvents.DELETE("/:id", middleware.RequireAdmin(), eventHandler.DeleteEvent)
			}
		}
	}

	// Health check
	router.GET("/health", func(c *gin.Context) {
		c.JSON(http.StatusOK, gin.H{"status": "ok"})
	})

	// Configurar servidor con graceful shutdown
	srv := &http.Server{
		Addr:    ":" + cfg.Server.Port,
		Handler: router,
	}

	// Iniciar el servidor en una goroutine
	go func() {
		log.Printf("Server starting on port %s", cfg.Server.Port)
		if err := srv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			log.Fatalf("listen: %s\n", err)
		}
	}()

	// Esperar señal para graceful shutdown
	quit := make(chan os.Signal, 1)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)
	<-quit
	log.Println("Shutting down server...")

	// Dar 5 segundos para cerrar conexiones existentes
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	if err := srv.Shutdown(ctx); err != nil {
		log.Fatal("Server forced to shutdown:", err)
	}

	log.Println("Server exiting")
}
