// pkg/auth/jwt.go
package auth

import (
	"errors"
	"time"

	"github.com/dgrijalva/jwt-go"
	"github.com/tuusuario/eventos-service/internal/models"
)

// JWTService define las operaciones relacionadas con tokens JWT
type JWTService interface {
	ValidateToken(tokenString string) (*models.JWTClaims, error)
}

type jwtService struct {
	secretKey string
}

// NewJWTService crea una nueva instancia de JWTService
func NewJWTService(secretKey string) JWTService {
	return &jwtService{
		secretKey: secretKey,
	}
}

// ValidateToken valida un token JWT y devuelve sus claims
func (s *jwtService) ValidateToken(tokenString string) (*models.JWTClaims, error) {
	token, err := jwt.Parse(tokenString, func(token *jwt.Token) (interface{}, error) {
		if _, ok := token.Method.(*jwt.SigningMethodHMAC); !ok {
			return nil, errors.New("método de firma inválido")
		}
		return []byte(s.secretKey), nil
	})

	if err != nil {
		return nil, err
	}

	claims, ok := token.Claims.(jwt.MapClaims)
	if !ok || !token.Valid {
		return nil, errors.New("token inválido")
	}

	// Verificar expiración
	if exp, ok := claims["exp"].(float64); ok {
		if time.Unix(int64(exp), 0).Before(time.Now()) {
			return nil, errors.New("token expirado")
		}
	}

	// Extraer claims
	userIDFloat, ok := claims["user_id"].(float64)
	if !ok {
		return nil, errors.New("claim 'user_id' inválido")
	}

	role, ok := claims["role"].(string)
	if !ok {
		return nil, errors.New("claim 'role' inválido")
	}

	return &models.JWTClaims{
		UserID: int(userIDFloat),
		Role:   role,
	}, nil
}
