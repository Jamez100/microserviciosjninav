// pkg/validators/validators.go
package validators

import (
	"time"

	"github.com/gin-gonic/gin/binding"
	"github.com/go-playground/validator/v10"
)

// RegisterCustomValidators registra validadores personalizados para Gin
func RegisterCustomValidators() {
	if v, ok := binding.Validator.Engine().(*validator.Validate); ok {
		// Valida que una fecha sea en el futuro
		v.RegisterValidation("future_date", validateFutureDate)
	}
}

// validateFutureDate valida que una fecha sea posterior a la fecha actual
func validateFutureDate(fl validator.FieldLevel) bool {
	date, ok := fl.Field().Interface().(time.Time)
	if !ok {
		return false
	}
	now := time.Now()
	return date.After(now)
}
