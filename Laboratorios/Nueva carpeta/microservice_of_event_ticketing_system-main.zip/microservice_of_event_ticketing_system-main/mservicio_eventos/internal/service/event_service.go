// internal/service/event_service.go
package service

import (
	"context"

	"github.com/tuusuario/eventos-service/internal/models"
	"github.com/tuusuario/eventos-service/internal/repository"
)

// EventService define las operaciones de servicio para la gestión de eventos
type EventService interface {
	GetAllEvents(ctx context.Context, onlyActive bool) ([]models.EventResponse, error)
	GetEventByID(ctx context.Context, id string) (*models.EventResponse, error)
	CreateEvent(ctx context.Context, req models.CreateEventRequest, userID int) (*models.EventResponse, error)
	UpdateEvent(ctx context.Context, id string, req models.UpdateEventRequest) (*models.EventResponse, error)
	DeleteEvent(ctx context.Context, id string) error
}

type eventService struct {
	repo repository.EventRepository
}

// NewEventService crea una nueva instancia de EventService
func NewEventService(repo repository.EventRepository) EventService {
	return &eventService{
		repo: repo,
	}
}

// GetAllEvents obtiene todos los eventos
func (s *eventService) GetAllEvents(ctx context.Context, onlyActive bool) ([]models.EventResponse, error) {
	events, err := s.repo.FindAll(ctx, onlyActive)
	if err != nil {
		return nil, err
	}

	var eventResponses []models.EventResponse
	for _, event := range events {
		eventCopy := event // Crear una copia para evitar problemas con el puntero
		eventResponses = append(eventResponses, eventCopy.ToResponse())
	}

	return eventResponses, nil
}

// GetEventByID obtiene un evento por su ID
func (s *eventService) GetEventByID(ctx context.Context, id string) (*models.EventResponse, error) {
	event, err := s.repo.FindByID(ctx, id)
	if err != nil {
		return nil, err
	}

	if event == nil {
		return nil, nil
	}

	response := event.ToResponse()
	return &response, nil
}

// CreateEvent crea un nuevo evento
func (s *eventService) CreateEvent(ctx context.Context, req models.CreateEventRequest, userID int) (*models.EventResponse, error) {
	event := &models.Event{
		Name:        req.Name,
		Description: req.Description,
		Date:        req.Date,
		Location:    req.Location,
		Capacity:    req.Capacity,
		Price:       req.Price,
		CreatedBy:   userID,
	}

	createdEvent, err := s.repo.Create(ctx, event)
	if err != nil {
		return nil, err
	}

	response := createdEvent.ToResponse()
	return &response, nil
}

// UpdateEvent actualiza un evento existente
func (s *eventService) UpdateEvent(ctx context.Context, id string, req models.UpdateEventRequest) (*models.EventResponse, error) {
	event := &models.Event{
		Name:        req.Name,
		Description: req.Description,
		Date:        req.Date,
		Location:    req.Location,
		Capacity:    req.Capacity,
		Price:       req.Price,
	}

	if req.IsActive != nil {
		event.IsActive = *req.IsActive
	}

	updatedEvent, err := s.repo.Update(ctx, id, event)
	if err != nil {
		return nil, err
	}

	if updatedEvent == nil {
		return nil, nil
	}

	response := updatedEvent.ToResponse()
	return &response, nil
}

// DeleteEvent elimina un evento (lo marca como inactivo)
func (s *eventService) DeleteEvent(ctx context.Context, id string) error {
	return s.repo.Delete(ctx, id)
}
