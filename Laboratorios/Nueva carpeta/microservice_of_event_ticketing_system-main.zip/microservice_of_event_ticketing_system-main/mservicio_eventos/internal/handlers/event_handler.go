// internal/handlers/event_handler.go
package handlers

import (
	"net/http"
	"strconv"

	"github.com/gin-gonic/gin"
	"github.com/tuusuario/eventos-service/internal/models"
	"github.com/tuusuario/eventos-service/internal/service"
)

// EventHandler maneja las solicitudes HTTP relacionadas con eventos
type EventHandler struct {
	eventService service.EventService
}

// NewEventHandler crea una nueva instancia de EventHandler
func NewEventHandler(eventService service.EventService) *EventHandler {
	return &EventHandler{
		eventService: eventService,
	}
}

// GetAllEvents godoc
// @Summary      Obtener todos los eventos
// @Description  Retorna una lista de todos los eventos
// @Tags         events
// @Accept       json
// @Produce      json
// @Param        active query boolean false "Solo eventos activos (default: true)"
// @Success      200  {array}   models.EventResponse
// @Failure      500  {object}  map[string]string
// @Router       /events [get]
func (h *EventHandler) GetAllEvents(c *gin.Context) {
	// Por defecto, solo obtener eventos activos
	onlyActive := true
	activeParam := c.DefaultQuery("active", "true")
	if activeParam == "false" {
		onlyActive = false
	}

	events, err := h.eventService.GetAllEvents(c.Request.Context(), onlyActive)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, events)
}

// GetEventByID godoc
// @Summary      Obtener un evento por ID
// @Description  Retorna un evento específico por su ID
// @Tags         events
// @Accept       json
// @Produce      json
// @Param        id  path      string  true  "ID del evento"
// @Success      200  {object}  models.EventResponse
// @Failure      404  {object}  map[string]string
// @Failure      500  {object}  map[string]string
// @Router       /events/{id} [get]
func (h *EventHandler) GetEventByID(c *gin.Context) {
	id := c.Param("id")

	event, err := h.eventService.GetEventByID(c.Request.Context(), id)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	if event == nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Event not found"})
		return
	}

	c.JSON(http.StatusOK, event)
}

// CreateEvent godoc
// @Summary      Crear un nuevo evento
// @Description  Crea un nuevo evento con los datos proporcionados
// @Tags         events
// @Accept       json
// @Produce      json
// @Param        event  body      models.CreateEventRequest  true  "Datos del evento"
// @Success      201    {object}  models.EventResponse
// @Failure      400    {object}  map[string]string
// @Failure      401    {object}  map[string]string
// @Failure      403    {object}  map[string]string
// @Failure      500    {object}  map[string]string
// @Security     BearerAuth
// @Router       /events [post]
func (h *EventHandler) CreateEvent(c *gin.Context) {
	var req models.CreateEventRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	// Obtener el ID del usuario del contexto (establecido por el middleware de autenticación)
	userID, exists := c.Get("userID")
	if !exists {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "User ID not found in context"})
		return
	}

	// Convertir userID a entero
	userIDInt, err := strconv.Atoi(userID.(string))
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Invalid user ID"})
		return
	}

	event, err := h.eventService.CreateEvent(c.Request.Context(), req, userIDInt)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusCreated, event)
}

// UpdateEvent godoc
// @Summary      Actualizar un evento existente
// @Description  Actualiza un evento con los datos proporcionados
// @Tags         events
// @Accept       json
// @Produce      json
// @Param        id    path      string                   true  "ID del evento"
// @Param        event body      models.UpdateEventRequest true  "Datos actualizados del evento"
// @Success      200   {object}  models.EventResponse
// @Failure      400   {object}  map[string]string
// @Failure      401   {object}  map[string]string
// @Failure      403   {object}  map[string]string
// @Failure      404   {object}  map[string]string
// @Failure      500   {object}  map[string]string
// @Security     BearerAuth
// @Router       /events/{id} [put]
func (h *EventHandler) UpdateEvent(c *gin.Context) {
	id := c.Param("id")

	var req models.UpdateEventRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	event, err := h.eventService.UpdateEvent(c.Request.Context(), id, req)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	if event == nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Event not found"})
		return
	}

	c.JSON(http.StatusOK, event)
}

// DeleteEvent godoc
// @Summary      Eliminar un evento
// @Description  Marca un evento como inactivo (borrado lógico)
// @Tags         events
// @Accept       json
// @Produce      json
// @Param        id  path      string  true  "ID del evento"
// @Success      204  {object}  nil
// @Failure      401  {object}  map[string]string
// @Failure      403  {object}  map[string]string
// @Failure      404  {object}  map[string]string
// @Failure      500  {object}  map[string]string
// @Security     BearerAuth
// @Router       /events/{id} [delete]
func (h *EventHandler) DeleteEvent(c *gin.Context) {
	id := c.Param("id")

	// Verificar si el evento existe
	event, err := h.eventService.GetEventByID(c.Request.Context(), id)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	if event == nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Event not found"})
		return
	}

	// Eliminar el evento (marcarlo como inactivo)
	if err := h.eventService.DeleteEvent(c.Request.Context(), id); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.Status(http.StatusNoContent)
}
