// internal/repository/event_repository.go
package repository

import (
	"context"
	"time"

	"github.com/tuusuario/eventos-service/internal/models"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

// EventRepository define las operaciones para manipular eventos en la base de datos
type EventRepository interface {
	FindAll(ctx context.Context, onlyActive bool) ([]models.Event, error)
	FindByID(ctx context.Context, id string) (*models.Event, error)
	Create(ctx context.Context, event *models.Event) (*models.Event, error)
	Update(ctx context.Context, id string, event *models.Event) (*models.Event, error)
	Delete(ctx context.Context, id string) error
}

type eventRepository struct {
	db         *mongo.Client
	database   string
	collection string
}

// NewEventRepository crea una nueva instancia de EventRepository
func NewEventRepository(db *mongo.Client, database string) EventRepository {
	return &eventRepository{
		db:         db,
		database:   database,
		collection: "events",
	}
}

// Collection retorna la colección de eventos
func (r *eventRepository) Collection() *mongo.Collection {
	return r.db.Database(r.database).Collection(r.collection)
}

// FindAll busca todos los eventos en la base de datos
func (r *eventRepository) FindAll(ctx context.Context, onlyActive bool) ([]models.Event, error) {
	filter := bson.M{}
	if onlyActive {
		filter["is_active"] = true
	}

	// Configurar opciones de búsqueda
	opts := options.Find().SetSort(bson.D{{Key: "date", Value: 1}})

	cursor, err := r.Collection().Find(ctx, filter, opts)
	if err != nil {
		return nil, err
	}
	defer cursor.Close(ctx)

	var events []models.Event
	if err := cursor.All(ctx, &events); err != nil {
		return nil, err
	}

	return events, nil
}

// FindByID busca un evento por su ID
func (r *eventRepository) FindByID(ctx context.Context, id string) (*models.Event, error) {
	objectID, err := primitive.ObjectIDFromHex(id)
	if err != nil {
		return nil, err
	}

	var event models.Event
	err = r.Collection().FindOne(ctx, bson.M{"_id": objectID}).Decode(&event)
	if err != nil {
		if err == mongo.ErrNoDocuments {
			return nil, nil
		}
		return nil, err
	}

	return &event, nil
}

// Create crea un nuevo evento en la base de datos
func (r *eventRepository) Create(ctx context.Context, event *models.Event) (*models.Event, error) {
	event.ID = primitive.NewObjectID()
	event.CreatedAt = time.Now()
	event.IsActive = true

	_, err := r.Collection().InsertOne(ctx, event)
	if err != nil {
		return nil, err
	}

	return event, nil
}

// Update actualiza un evento existente
func (r *eventRepository) Update(ctx context.Context, id string, event *models.Event) (*models.Event, error) {
	objectID, err := primitive.ObjectIDFromHex(id)
	if err != nil {
		return nil, err
	}

	// Crear objeto de actualización
	update := bson.M{}
	if event.Name != "" {
		update["name"] = event.Name
	}
	if event.Description != "" {
		update["description"] = event.Description
	}
	if !event.Date.IsZero() {
		update["date"] = event.Date
	}
	if event.Location != "" {
		update["location"] = event.Location
	}
	if event.Capacity > 0 {
		update["capacity"] = event.Capacity
	}
	if event.Price >= 0 {
		update["price"] = event.Price
	}
	if event.IsActive {
		update["is_active"] = event.IsActive
	}

	result := r.Collection().FindOneAndUpdate(
		ctx,
		bson.M{"_id": objectID},
		bson.M{"$set": update},
		options.FindOneAndUpdate().SetReturnDocument(options.After),
	)

	if result.Err() != nil {
		if result.Err() == mongo.ErrNoDocuments {
			return nil, nil
		}
		return nil, result.Err()
	}

	var updatedEvent models.Event
	if err := result.Decode(&updatedEvent); err != nil {
		return nil, err
	}

	return &updatedEvent, nil
}

// Delete elimina un evento por su ID (marcándolo como inactivo)
func (r *eventRepository) Delete(ctx context.Context, id string) error {
	objectID, err := primitive.ObjectIDFromHex(id)
	if err != nil {
		return err
	}

	_, err = r.Collection().UpdateOne(
		ctx,
		bson.M{"_id": objectID},
		bson.M{"$set": bson.M{"is_active": false}},
	)

	return err
}
