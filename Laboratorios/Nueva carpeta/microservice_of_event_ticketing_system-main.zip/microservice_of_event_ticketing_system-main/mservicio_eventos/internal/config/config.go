// internal/config/config.go
package config

import (
	"context"
	"log"
	"os"
	"time"

	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
	"go.mongodb.org/mongo-driver/mongo/readpref"
)

// Config almacena la configuración global de la aplicación
type Config struct {
	Server struct {
		Port string
		Host string
	}
	MongoDB struct {
		URI      string
		Database string
	}
	JWT struct {
		Secret string
	}
}

// LoadConfig carga la configuración desde variables de entorno
func LoadConfig() *Config {
	cfg := &Config{}

	// Configuración del servidor
	cfg.Server.Port = getEnv("SERVER_PORT", "8082")
	cfg.Server.Host = getEnv("SERVER_HOST", "localhost")

	// Configuración de MongoDB
	cfg.MongoDB.URI = getEnv("MONGODB_URI", "mongodb://localhost:27017")
	cfg.MongoDB.Database = getEnv("MONGODB_DATABASE", "com600_event_system_event_service_go")

	// Configuración de JWT
	cfg.JWT.Secret = getEnv("JWT_SECRET", "your-secret-key")

	return cfg
}

// ConnectMongoDB establece conexión con MongoDB
func ConnectMongoDB(cfg *Config) (*mongo.Client, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	clientOptions := options.Client().ApplyURI(cfg.MongoDB.URI)
	client, err := mongo.Connect(ctx, clientOptions)
	if err != nil {
		return nil, err
	}

	// Verificar la conexión
	if err := client.Ping(ctx, readpref.Primary()); err != nil {
		return nil, err
	}

	log.Println("Connected to MongoDB successfully")
	return client, nil
}

// getEnv obtiene una variable de entorno o devuelve un valor por defecto
func getEnv(key, defaultValue string) string {
	if value, exists := os.LookupEnv(key); exists {
		return value
	}
	return defaultValue
}
