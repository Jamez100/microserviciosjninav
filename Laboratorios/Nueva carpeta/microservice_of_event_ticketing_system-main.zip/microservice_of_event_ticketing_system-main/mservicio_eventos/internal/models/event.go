// internal/models/event.go
package models

import (
	"time"

	"go.mongodb.org/mongo-driver/bson/primitive"
)

// Event representa el modelo de un evento
type Event struct {
	ID          primitive.ObjectID `json:"id" bson:"_id,omitempty"`
	Name        string             `json:"name" bson:"name" binding:"required"`
	Description string             `json:"description" bson:"description"`
	Date        time.Time          `json:"date" bson:"date" binding:"required"`
	Location    string             `json:"location" bson:"location" binding:"required"`
	Capacity    int                `json:"capacity" bson:"capacity" binding:"required,min=1"`
	Price       float64            `json:"price" bson:"price" binding:"required,min=0"`
	CreatedBy   int                `json:"created_by" bson:"created_by"`
	CreatedAt   time.Time          `json:"created_at" bson:"created_at"`
	IsActive    bool               `json:"is_active" bson:"is_active"`
}

// CreateEventRequest representa el cuerpo de la solicitud para crear un evento
type CreateEventRequest struct {
	Name        string    `json:"name" binding:"required"`
	Description string    `json:"description"`
	Date        time.Time `json:"date" binding:"required" time_format:"2006-01-02T15:04:05Z07:00"`
	Location    string    `json:"location" binding:"required"`
	Capacity    int       `json:"capacity" binding:"required,min=1"`
	Price       float64   `json:"price" binding:"required,min=0"`
}

// UpdateEventRequest representa el cuerpo de la solicitud para actualizar un evento
type UpdateEventRequest struct {
	Name        string    `json:"name"`
	Description string    `json:"description"`
	Date        time.Time `json:"date" time_format:"2006-01-02T15:04:05Z07:00"`
	Location    string    `json:"location"`
	Capacity    int       `json:"capacity" binding:"min=0"`
	Price       float64   `json:"price" binding:"min=0"`
	IsActive    *bool     `json:"is_active"`
}

// EventResponse representa la respuesta de un evento
type EventResponse struct {
	ID          string    `json:"id"`
	Name        string    `json:"name"`
	Description string    `json:"description"`
	Date        time.Time `json:"date"`
	Location    string    `json:"location"`
	Capacity    int       `json:"capacity"`
	Price       float64   `json:"price"`
	CreatedAt   time.Time `json:"created_at"`
	IsActive    bool      `json:"is_active"`
}

// ToResponse convierte un modelo Event a EventResponse
func (e *Event) ToResponse() EventResponse {
	return EventResponse{
		ID:          e.ID.Hex(),
		Name:        e.Name,
		Description: e.Description,
		Date:        e.Date,
		Location:    e.Location,
		Capacity:    e.Capacity,
		Price:       e.Price,
		CreatedAt:   e.CreatedAt,
		IsActive:    e.IsActive,
	}
}

// JWTClaims representa los claims de un token JWT
type JWTClaims struct {
	UserID int    `json:"user_id"`
	Role   string `json:"role"`
}
